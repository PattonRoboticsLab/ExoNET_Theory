% set as many parameters as possible for exonet applications
% VERSIONS:     Patton simplified 
%               Patton initiated 2019-01-11
% 
%       | PHI2  .
%       |      .
%       |    .
%       |   .
%       |  .
%       | .
%       o
%      /  
%     /  
%    /
%   /   PHI 1
%  o . . . . . . .
%
%% ~~ BEGIN PROGRAM: ~~
global Exo Bod PHIs TAUsDesired tension 
fprintf('\n _____ setup 4  Weight-comp : ____ \n')
put_fig(1,.025,.11,.75,.8);  subplot(1,2,1) % clear and set display:
title('Gravity Compensating Field');               

%% MARIONETS
Exo.K=1000;          % spring Stiffness 
Exo.nParams=3;      % number of parameters governing each element
Exo.nJnts=3;        % shoulder and elbow and shoulder elbow 
Exo.nElements=2     % number of stacked elements per joint

%% Bod
Bod.M = 70;                   % body mass 
Bod.L = [.35 .26;];           % segment lengths (humerous, arm)
Bod.R = Bod.L.*[.45 .5];      % proximal to centers of mass of segments 

%% set full span of posture evaluation points (angles)
nAngles = 7; % # shoulder & elbow angles in a span for evaluation
phi1=pi/180*linspace(-100,0,nAngles); phi2=pi/180*linspace(25,145,nAngles);  
PHIs=[];  
for i=1:length(phi1), % nested 2 loop establishes grid of phi combinations
  for j=1:length(phi2), PHIs=[PHIs; phi1(i),phi2(j)]; end; % stack up list
end; 
Pos=forwardKin(PHIs,Bod);   % positions assoc w/ these angle combinations

%% set one token body pose
phiPose=pi/180*[-97 70];    % one single sample pose for drawings
drawBody2(phiPose, Bod);    % draw at one posture
%plot(Pos.wr(:,1),Pos.wr(:,2),'.','color',.8*[1 1 1]); % plot positions grey

%% Optimization params:
options.MaxIter = 1E4;                            % optimization limit
options.MaxFunEvals = 1E4;                        % optimization limit
options.nTries = 15                               % #random init restarts
p0=.05*(1:(Exo.nParams*Exo.nElements*Exo.nJnts)); % INIT.GUESS (L0,r,theta)
bestCost=1e16;                                    % init very high 

%% Define inline anon fcn
tension = @(L0,L)    (Exo.K.*(L-L0)).*((L-L0)>0); % (inlineFcn) +Stretch

%% problem-specific for gravity comp on the arm
TAUsDesired=weightEffect(Bod,Pos);                % set torques2cancelGrav
plotVectField(PHIs,Bod,Pos,TAUsDesired,'r');      % plot desired field 

fprintf(' parameters set. \n ')

