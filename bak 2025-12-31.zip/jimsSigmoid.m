% jim's sigmoid function

function y=jimsSigmoid(x,sigma,x0,gain,plotIt) % sigmoid

if ~exist('x','var')
    fprintf('\n  syntax: y=sigmoid(x,sigma,x0,gain)\nmaking up inputs:\n')
    x=-.3:.01:.4
    sigma=.03            % variance
    x0=.1
    gain=1
end
y = gain./(1+exp(-(x-x0)./sigma).^2);

if plotIt, plot(x,y,'.-'); end

end 
% old code
% activationGain=100;
% y = gain./(1+exp(-activationGain*(x-x0))./(sigma)^2);
