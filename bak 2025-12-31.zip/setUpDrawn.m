% set as many parameters as possible for exonet applications
% VERSIONS:     Patton initiated from setUpGravArm 2025-OCt-4
% 
%       | PHI 2 .
%       |      .
%       |    .
%       |   .
%       |  .
%       | .
%       o
%      /  
%     /  
%    /
%   /   PHI 1
%  o . . . . . . .
%
%% ~~ BEGIN PROGRAM: ~~

fprintf('\n\n _____ ExoNET drawn field setup: ____ \n')

%% set one token body pose
figure(4); clf; put_fig(4,.03,.5,.44,.41); clf; hold on; % clear & set 
set(gcf,'name','Drawn')
subplot(1,2,1); drawBody2(pi/180*[-100 70], Bod); % draw at one posture
title('You draw the Desired Field');    

%% set full span of posture evaluation points (angles)
nAngles = 7; % # shoulder & elbow angles in a span for evaluation
phi1=pi/180*linspace(-100,0,nAngles); phi2=pi/180*linspace(30,145,nAngles);  
PHIs=[];  
for i=1:length(phi1), % nested 2 loop establishes grid of phi combinations
  for j=1:length(phi2), PHIs=[PHIs; phi1(i),phi2(j)]; end; % stack up list
end; 
Pos=forwardKin(PHIs,Bod);   % positions assoc w/ these angle combinations
plot(Pos.wr(:,1),Pos.wr(:,2),'.','color',.8*[1 1 1]); % testPoints in grey

bestCost=1e16;                                    % init very high 

%% problem-specific for EA on the positions along traject
[TAUsDesired,PHIs,Pos]=drawnField(Bod);
plotVectField(PHIs,Bod,Pos,TAUsDesired,'r');        % plot desired field 
drawnow

fprintf(' parameters set. \n ')

