TAUsDesired=getAttractorField(Pos);                 % set torques2cancelGrav
global PHIs

mag=sigmoid(fromCtr,sigma,x0,gain) % sigmoid

if ~exist('x','var')
    fprintf('\n  syntax: y=sigmoid(x,sigma,x0,gain)\nmaking up inputs:\n')
    x=-.3:.01:.4
    sigma=.03            % variance
    x0=.1
    gain=1
end
y = gain./(1+exp(-(x-x0)./sigma).^2);
plot(x,y,'.-');

 
% old code
% activationGain=100;
% y = gain./(1+exp(-activationGain*(x-x0))./(sigma)^2);
